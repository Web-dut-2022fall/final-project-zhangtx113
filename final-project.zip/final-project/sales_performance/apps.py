from django.apps import AppConfig


class SalesPerformanceConfig(AppConfig):
    name = 'sales_performance'
